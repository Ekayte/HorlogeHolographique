/*
 * test.h
 *
 *  Created on: 3 nov. 2016
 *      Author: Nirgal
 */

#ifndef TEST_H_
#define TEST_H_

void test(void);

#endif /* TEST_H_ */
